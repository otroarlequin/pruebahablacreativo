<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href=".\css\bootstrap.css" crossorigin="anonymous">
	<link rel="stylesheet" href=".\css\style.css">

	<meta https-equiv="Content-Type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
</head>
<body>
	<header>
		<nav class="navbar navbar-expand-lg bg-nav" id="bg-nav">
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExample08" aria-controls="navbarsExample08" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<img src="resources/Remanso-05.png" class="logo"/>
			<div class="collapse navbar-collapse justify-content-md-center" id="navbarsExample08">
				<ul class="navbar-nav">
					<li class="nav-item active">
						<a class="nav-link" href="#">Proyecto</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Galeria</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Apartamentos</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Mapa</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="#">Contacto</a>
					</li>
				</ul>
			</div>
		</nav>
	</header>
	<section id="home">
		<div class="container">
			<div class="row justify-content-md-center" id="principal">
				<div class="col-sm-6 col-xs-hidden" id="bono"></div>
				<div class="col-sm-6 col-xs-hidden" id="formulario">
					<div class="row justify-content-md-center">
						<div class="col-sm-12">
							<form>
								<table cellpadding="10">
									<tr>
										<td><input type="text" class="form-control"></td>
									</tr>
									<tr>
										<td><input type="text" class="form-control"></td>
									</tr>
									<tr>
										<td><input type="text" class="form-control"></td>
									</tr>
									<tr>
										<td><input type="text" class="form-control"></td>
									</tr>
									<tr>
										<td><textarea rows="3" class="form-control"></textarea></td>
									</tr>
								</table>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section id="apartamentos">
		<div class="container">
			<figure>
				<img src="resources/Remanso-19.png" class="price-large"/>
				<img src="resources/Remanso-20.png" class="price-short" />
				<figcaption></figcaption>
			</figure>
			<div class="row">
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-21.png"></div>
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-22.png"></div>
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-23.png"></div>
			</div>
			<div class="row">
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-24.png"></div>
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-25.png"></div>
				<div class="col-sm-4"><img class="img-responsive" src="resources/Remanso-26.png"></div>
			</div>
		</div>
	</section>
	<section id="footer">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1 class="text-uppercase">sala de negocios</h1>
				</div>
			</div>
			<div class="row">
				<div class="col-sm-3" class="text-center">
					<img src="resources/Remanso-31.png"/>
					<p class="font-weight-bold">
						Tel:
						<br>
						3439241 - 3137050212
					</p>
				</div>
				<div class="col-sm-3">
					<img src="resources/Remanso-32.png"/>
					<p class="font-weight-bold">
						Dirección:<br/>
						Calle 6 sur # 79 - 158 Medellín
					</p>
				</div>
				<div class="col-sm-3">
					<img src="resources/Remanso-33.png"/>
					<p class="font-weight-bold">Hora de Atención:
						<br/>
						10:00 am - 5:30pm
					</p>
				</div>
				<div class="col-sm-3">
					<img src="resources/Remanso-34.png"/>
					<p class="font-weight-bold">
						Correo:<br/>
						<span class="font-weight-normal">remansodelrodeo@une.net.co</span>
					</p>
				</div>
			</div>
			<div class="row" style="padding-top: 20px;">
				<p>Las imágenes utilizadas sons representaciones digitales del diseño y junto con las oficinas, locales y apartamentos pueden variar en la construcción final. El mobiliario, electrodomésticos, gasodomésticos, acabados y demás elementos que aparecen en las imagenes son una representación a fin de ilustrar la utilización de los espacios y pueden diferir de lo entregado a no ser entregado según lo convenido en los contratos.Las áreas privadas y construidas podrán sufrir ajustes y quedarán finalmente determinadas en los contratos suscritos por las partes</p>
			</div>
			<div class="row" style="padding-top: 20px;">
				<img src="resources/Remanso-35.png"/>
			</div>
		</div>
	</section>
</body>
</html>